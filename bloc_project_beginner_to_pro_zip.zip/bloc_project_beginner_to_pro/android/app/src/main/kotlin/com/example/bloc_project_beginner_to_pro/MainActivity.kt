package com.example.bloc_project_beginner_to_pro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
